<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Task;
use App\Details;

class DetailController extends Controller
{
    protected $guarded = [];
    public function store(Request $request,$id)
    {
    //  dd($request->all());
        $task=new Details;

        $task->create([
            'task_id'=>$id,
            'name'=>$request->name,
            'email'=>$request->email,
            'comment'=>$request->comment
            ]);
        
        return back();
    }


}
