@extends('layouts.master')

    @section('content')
        <div class="col-sm-8 blog-main">
            <h1>{{ $task->title }}</h1>
            <p class="blog-post-meta">{{ $task->created_at->toFormattedDateString()}}</p>
            {{ $task->description }} 
        <hr>
        @if ($task->details->count())
            <div >
                @foreach ($task->details as $detail)
                <strong>{{ $detail->created_at->diffForHumans()}}:<strong>   
                <ul>
                        <li>{{ $detail->name }}</li>
                        <li>{{ $detail->email}}</li>
                        <li>{{ $detail->comment}}</li>
                </ul>   
                
                @endforeach
            </div>
        @endif
        <hr>
        <div class="box">
            <div class="card-block">
                <form method="POST" action = "/tasks/{{$task->id}}/details " class="box">
                    {{ csrf_field() }}
                        <div class="field">
                            <label for="name">Name:</label>
                            <input type="text" class="control" id="name" name="name">
                        </div>                  
                        <div class="field">
                            <label for="email">Email:</label>
                            <input type="text" class="control" id="email" name="email">
                        </div>
                        <div class="field">
                            <label for="comment">Comment:</label>
                            <textarea name="comment" id="comment" class="control" ></textarea>
                        </div>
                        <hr>
                        <button type="submit" class="btn btn-info">Add Comment</button>
                </form>        
            </div>
        </div>
        <hr> 
        </div>
    @endsection