@extends('layouts.master')

  @section('content')
    <div class="col-sm-8 blog-main">
      <h3>Create Task</h3>
      <hr>

      <form method="POST" action = "/tasks">
          {{ csrf_field() }}

          <div class="form-group">
            <label for="title">Title:</label>
            <input type="text" class="form-control" id="title" name="title">
          </div>

          <div class="form-group">
            <label for="description">Description</label>
            <textarea name="description" id="description" class="form-control" ></textarea>
          </div>
            
          <button type="submit" class="btn btn-info">Create</button>
          
      </form>
    </div>

  @endsection