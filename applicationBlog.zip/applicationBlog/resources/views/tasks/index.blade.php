@extends('layouts.master')

    @section('content')

    <div>
        <button class="btn btn-primary" type="submit" >new</button>
    </div>
    <hr>
    <div class="col-sm-8 blog-main">
            
        @foreach ($tasks as $task)
        
            <a href="/tasks/{{$task->id}}">
                {{$task->title}}
            </a>

            <p class="blog-post-meta">{{ $task->created_at->toFormattedDateString()}}</p>

            {{ $task->description }}

            <hr>

        @endforeach
    
        </div>
    @endsection
