<?php /* /home/ashwinig/Documents/PHP_Training/applicationBlog/resources/views/tasks/show.blade.php */ ?>
    <?php $__env->startSection('content'); ?>
        <div class="col-sm-8 blog-main">
            <h1><?php echo e($task->title); ?></h1>
            <p class="blog-post-meta"><?php echo e($task->created_at->toFormattedDateString()); ?></p>
            <?php echo e($task->description); ?> 
        <hr>
        <?php if($task->details->count()): ?>
            <div >
                <?php $__currentLoopData = $task->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <strong><?php echo e($detail->created_at->diffForHumans()); ?>:<strong>   
                <ul>
                        <li><?php echo e($detail->name); ?></li>
                        <li><?php echo e($detail->email); ?></li>
                        <li><?php echo e($detail->comment); ?></li>
                </ul>   
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
        <hr>
        <div class="box">
            <div class="card-block">
                <form method="POST" action = "/tasks/<?php echo e($task->id); ?>/details " class="box">
                    <?php echo e(csrf_field()); ?>

                        <div class="field">
                            <label for="name">Name:</label>
                            <input type="text" class="control" id="name" name="name">
                        </div>                  
                        <div class="field">
                            <label for="email">Email:</label>
                            <input type="text" class="control" id="email" name="email">
                        </div>
                        <div class="field">
                            <label for="comment">Comment:</label>
                            <textarea name="comment" id="comment" class="control" ></textarea>
                        </div>
                        <hr>
                        <button type="submit" class="btn btn-info">Add Comment</button>
                </form>        
            </div>
        </div>
        <hr> 
        </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>