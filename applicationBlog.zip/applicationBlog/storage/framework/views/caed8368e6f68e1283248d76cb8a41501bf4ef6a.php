<?php /* /home/ashwinig/Documents/PHP_Training/curdblog/resources/views/tasks/create.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div class="col-sm-8 blog-main">
<h3>Create Task</h3>
<hr>

<form method="POST" action = "/tasks">
<?php echo e(csrf_field()); ?>


  <div class="form-group">
    <label for="employee_name">Employee_Name:</label>
    <input type="text" class="form-control" id="employee_name" name="employee_name">
  </div>
  <div class="form-group">
    <label for="description">Description</label>
    <textarea name="description" id="description" class="form-control" ></textarea>
    
  </div>
  
  <button type="submit" class="btn btn-info">Create</button>
</form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>