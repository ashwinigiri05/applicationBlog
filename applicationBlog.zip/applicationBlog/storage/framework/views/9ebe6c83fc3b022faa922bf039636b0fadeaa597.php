<?php /* /home/ashwinig/Documents/PHP_Training/curdblog/resources/views/layouts/sidebar.blade.php */ ?>
<div class="col-sm-3 col-sm-offset-1 blog-sidebar">
               
                <div class="sidebar-module">
                   <h4>Archives</h4>
                    <ol class="list-unstyled">
                        <li><a href="#">March 2019</a></li>
                        <li><a href="#">February 2018</a></li>
                        <li><a href="#">January 2018</a></li>
                        <li><a href="#">December 2018</a></li>
                        <li><a href="#">November 2018</a></li>
                        <li><a href="#">October 2018</a></li>
                        <li><a href="#">September 2018</a></li>
                        <li><a href="#">August 2018</a></li>
                        <li><a href="#">July 2018</a></li>
                        <li><a href="#">June 2018</a></li>
                        <li><a href="#">May 2018</a></li>
                        <li><a href="#">April 2018</a></li>
                    </ol>
                </div>
                <div class="sidebar-module">
                 <h4>Elsewhere</h4>
                <ol class="list-unstyled">
                    <li><a href="#">GitHub</a></li>
                    <li><a href="#">Twitter</a></li>
                    <li><a href="#">Facebook</a></li>
                </ol>
                </div>

            </div>