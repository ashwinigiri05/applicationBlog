<?php /* /home/ashwinig/Documents/PHP_Training/curdblog/resources/views/welcome.blade.php */ ?>
<!-- <!DOCTYPE html>
<html lang="en">
<head>
       <title>Document</title>
</head>
<body>
  <ul>
    <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><?php echo e($task); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
</body>
</html> -->